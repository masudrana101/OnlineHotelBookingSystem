<h3>Hi {{$name}}</h3>
<h4>Well come to hotel booking syatem . your account has been create</h4>
<h4> your password is {{ $password }}</h4>