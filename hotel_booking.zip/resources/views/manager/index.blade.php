@extends('layouts.manager_layout')

@section('stylesheet')
@endsection
@section('title')
    Dashbboard
@endsection
@section('content')

@endsection
@section('script')
@endsection
