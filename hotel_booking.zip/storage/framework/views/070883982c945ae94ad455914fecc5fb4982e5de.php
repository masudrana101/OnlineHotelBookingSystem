
<?php $__env->startSection('stylesheet'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <section class="panel">
                        <header class="panel-heading mb-5">
                            <h2 class="panel-title">Add Room</h2>
                        </header>
                        <div class="panel-body">
                            <?php if(session()->has('status')): ?>
                                <?php echo session()->get('status'); ?>

                            <?php endif; ?>
                            <form action="<?php echo e(route('manager.hotel.room.add', $hotel->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Room No/Name<span class="text-danger">*</span></label>
                                            <input type="text" name="room_number" placeholder="Room number / name" required
                                                   value="<?php echo e(old('room_number')); ?>"
                                                   class="form-control <?php $__errorArgs = ['room_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <?php $__errorArgs = ['room_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger"><?php echo e($errors->first('room_number')); ?></strong>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="control-label">Room Type<span
                                                        class="text-danger">*</span></label>
                                            <select name="room_type_id" required
                                                    class="form-control <?php $__errorArgs = ['room_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="">Choose a Room Type</option>
                                                <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($val->id); ?>" <?php if(old('room_type_id') == $val->id): ?> selected <?php endif; ?>><?php echo e($val->name.' ('.$val->capacity.' P)'); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['room_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger"><?php echo e($errors->first('room_type_id')); ?></strong>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-sm-6 mt-2">
                                        <label class="mr-5">Attached Bathroom</label>
                                        <label class="mr-5" for="attached_bath_yes"><input type="radio" id="attached_bath_yes" class="mr-2"
                                                                                name="attached_bath" value="yes" checked>Yes</label>
                                        <label for="attached_bath_no"><input type="radio" id="attached_bath_no" class="mr-2"
                                                                     name="attached_bath" value="no" <?php if(old('attached_bath') == 'no'): ?> checked <?php endif; ?>> No</label>
                                    </div>
                                    <div class="col-sm-6 mt-2">
                                        <label class="mr-5">Type</label>
                                        <label class="mr-5" for="type_non_ac"><input type="radio" id="type_non_ac" class="mr-2"
                                                                                name="type" value="non ac" checked>Non Ac</label>
                                        <label for="type_ac"><input type="radio" id="type_ac" class="mr-2"
                                                                     name="type" value="ac" <?php if(old('type') == 'ac'): ?> checked <?php endif; ?>> Ac</label>
                                    </div>
                                </div>
                                <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label class="control-label">Amount / Price <span
                                                            class="text-danger"> *</span></label>
                                                <input type="number" name="amount" placeholder="Amount / Price"
                                                       value="<?php echo e(old('amount')); ?>" required
                                                       class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <strong class="text-danger"><?php echo e($errors->first('amount')); ?></strong>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    <div class="col-sm-6 mt-4">
                                        <label class="mr-5">Status</label>
                                        <label class="mr-5" for="available"><input type="radio" id="available" class="mr-2"
                                                                                name="status" value="available" checked>
                                            Available</label>
                                        <label for="unavailable"><input type="radio" id="unavailable" class="mr-2"
                                                                     name="status" value="unavailable" <?php if(old('status') == 'unavailable'): ?> checked <?php endif; ?>> Unavailable</label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <label class="control-label">Description</label>
                                            <textarea name="description" cols="30" rows="2" placeholder="Room description"
                                                      class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description')); ?></textarea>
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <strong class="text-danger"><?php echo e($errors->first('description')); ?></strong>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-sm-12 text-right">
                                        <button class="btn btn-success btn-sm" type="submit">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel_booking\resources\views/manager/room/add.blade.php ENDPATH**/ ?>