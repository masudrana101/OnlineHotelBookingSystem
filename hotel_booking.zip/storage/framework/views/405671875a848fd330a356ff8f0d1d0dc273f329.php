

<?php $__env->startSection('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendor/jquery-datatables-bs3/assets/css/datatables.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <section class="panel">
                        <header class="panel-heading">
                            <h2 class="panel-title">View Room Booking</h2>
                        </header>
                        <div class="panel-body">
                            <?php if(session()->has('status')): ?>
                                <?php echo session()->get('status'); ?>

                            <?php endif; ?>
                            
                                
                                    
                                
                            
                            <table class="table table-bordered table-striped mb-none" id="data-table">
                                <thead>
                                <tr>
                                    <th width="50">#</th>
                                    <th>Customer</th>
                                    <th>Room</th>
                                    <th>Payment</th>
                                    <th width="220">Interval</th>
                                    <th width="70">Status</th>
                                    
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php if(($loop->iteration %2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                                        <td><?php echo e(($loop->iteration  +1)); ?></td>
                                        <td class="text-capitalize" >
                                            <strong><?php echo e($val->user->name); ?></strong><br>
                                            <span><?php echo e($val->user->phone); ?></span><br>
                                            <span><?php echo e($val->user->email); ?></span><br>
                                        </td>
                                        <td class="text-capitalize" >
                                            <strong><?php echo e($val->room->hotel->name); ?></strong><br>
                                            <span><?php echo e($val->room->room_number); ?> -> <span><?php echo e($val->room->roomType->name); ?> <span>(<?php echo e($val->room->roomType->capacity); ?> P)</span></span></span><br>
                                            <strong class="text-indigo"><?php echo e($val->room->amount); ?> TK / Night</strong>
                                        </td>
                                        <td>
                                            <strong>Pay: <?php echo e($val->amount); ?> TK</strong><br>
                                            <span class="text-capitalize">By: <?php echo e($val->payment_by); ?></span><br>
                                        </td>
                                        <td>
                                            <span><?php echo e($val->check_in); ?> to <?php echo e($val->check_out); ?></span><br>
                                            <span>Apply at: </span><br>
                                            <span><?php echo e(date('F d, Y h:i A', strtotime($val->created_at))); ?></span>
                                        </td>
                                        <td class="text-capitalize">
                                            <form action="<?php echo e(route('manager.change.booking.status')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($val->id); ?>">
                                                <select name="status" >
                                                    <option value="pending" <?php if($val->status == 'pending'): ?> selected <?php endif; ?>>Pending</option>
                                                    <option value="booked" <?php if($val->status == 'booked'): ?> selected <?php endif; ?>>Booked</option>
                                                    <option value="canceled" <?php if($val->status == 'canceled'): ?> selected <?php endif; ?>>Canceled</option>
                                                    <option value="completed" <?php if($val->status == 'completed'): ?> selected <?php endif; ?>>Completed</option>
                                                </select>
                                            </form>
                                            
                                        </td>
                                        
                                            
                                            
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables/media/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables-bs3/assets/js/datatables.js')); ?>"></script>
    <script>
      $(document).ready(function () {
        $('#data-table').DataTable();
        $(document.body).on('change', 'select[name="status"]', function () {
          const select = $(this).val();
          if(select !== '') {
            $(this).closest('form').submit()
          }
        })
      })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel_booking\resources\views/manager/booking/booked.blade.php ENDPATH**/ ?>