

<?php $__env->startSection('stylesheet'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendor/jquery-datatables-bs3/assets/css/datatables.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="row">
    <div class="col-12">
      <div class="card">
        <div class="card-body">
          <section class="panel">
            <header class="panel-heading">
              <h2 class="panel-title">View Hotel</h2>
            </header>
            <div class="panel-body">
              <?php if(session()->has('status')): ?>
                <?php echo session()->get('status'); ?>

              <?php endif; ?>
                <table class="table table-bordered table-striped mb-none" id="data-table">
                  <thead>
                  <tr>
                    <th width="50">#</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th width="220">Created At</th>
                    <th width="70">Status</th>
                    <th class="hidden-phone" width="100">Option</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php if(($key%2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                      <td><?php echo e(($key+1)); ?></td>

                      <td class="text-capitalize" ><?php echo e($val->name); ?></td>
                      <td><?php echo e((strlen($val->address) > 100) ?  substr($val->address, 0, 100)."..." : $val->address); ?></td>
                      <td><?php echo e(date('F d, Y h:i A', strtotime($val->created_at))); ?></td>
                      <td class="text-capitalize" width="100">
                        <div class="onoffswitch">
                          <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox"
                                 <?php if($val->status == 'active'): ?>
                                 checked
                                 <?php endif; ?>
                                 data-id="<?php echo e($val->id); ?>"
                                 id="myonoffswitch<?php echo e(($key+1)); ?>">
                          <label class="onoffswitch-label" for="myonoffswitch<?php echo e(($key+1)); ?>">
                            <span class="onoffswitch-inner"></span>
                            <span class="onoffswitch-switch"></span>
                          </label>
                        </div>
                      </td>
                      <td class="center hidden-phone" width="100">
                        <a href="<?php echo e(route('admin.hotel.edit', $val->id)); ?>" class="btn btn-sm btn-success"> <i class="fa fa-edit"></i> </a>
                        <span style="cursor: pointer" class="btn btn-sm btn-danger btn-delete delete_<?php echo e($val->id); ?>" data-id="<?php echo e($val->id); ?>"><i class="fa fa-trash-o"></i></span>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </div>
          </section>
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="hotelDeleteModal" tabindex="-1" role="dialog" aria-labelledby="hotelDeleteModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
            <h4>Delete Hotel</h4>
        </div>
        <div class="modal-body">
          <strong>Are you sure to delete this Hotel?</strong>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">No</button>
          <button type="button" class="btn btn-success btn-sm yes-btn">Yes</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

  <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables/media/js/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables-bs3/assets/js/datatables.js')); ?>"></script>
  <script>
    $(document).ready(function () {
      $('#data-table').DataTable();


      $(document).on('change', 'input[name="onoffswitch"]', function () {
        var status = 'inactive';
        var id = $(this).data('id')
        var isChecked = $(this).is(":checked");
        if (isChecked) {
          status = 'active';
        }
        // console.log(id)
        $.ajax({
          url: "<?php echo e(route('admin.ajax.update.hotel.status')); ?>",
          method: "post",
          dataType: "html",
          data: {id, status},
          success: function (data) {
            if (data === "success") {
            }
          }
        });
      })



      $(document).on('click', '.yes-btn', function () {
        var pid = $(this).data('id');
        var $this = $('.delete_' + pid)
        $.ajax({
          url: "<?php echo e(route('admin.hotel.delete')); ?>",
          method: "delete",
          dataType: "html",
          data: {id: pid},
          success: function (data) {
            if (data === "success") {
              $('#hotelDeleteModal').modal('hide')
              $this.closest('tr').css('background-color', 'red').fadeOut();
            }
          }
        });
      })

      $(document).on('click', '.btn-delete', function () {
        var pid = $(this).data('id');
        $('.yes-btn').data('id', pid);
        $('#hotelDeleteModal').modal('show')
      });
    })
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel_booking\resources\views/admin/hotel/view.blade.php ENDPATH**/ ?>