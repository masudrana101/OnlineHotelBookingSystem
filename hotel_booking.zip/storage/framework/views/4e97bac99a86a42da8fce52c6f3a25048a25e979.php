

<?php $__env->startSection('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendor/jquery-datatables-bs3/assets/css/datatables.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <section class="panel">
                        <header class="panel-heading">
                            <h2 class="panel-title">Hotel Details</h2>
                        </header>
                        <div class="panel-body">
                            <?php if(session()->has('status')): ?>
                                <?php echo session()->get('status'); ?>

                            <?php endif; ?>
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-xl-12 text-right mb-3">
                                    <a href="<?php echo e(route('manager.hotel.view')); ?>"
                                       class="brn btn-primary btn-sm">Hotels</a>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12 col-lg-6 col-xl-8">
                                            <h3 class="text-capitalize">Name: <?php echo e($hotel->name); ?></h3>
                                            <h6>Phone: <?php echo e($hotel->phone); ?></h6>
                                            <h6>Email: <?php echo e($hotel->email); ?></h6>
                                            <h6>Address: <?php echo e($hotel->address); ?></h6>
                                            <h6 class="text-capitalize">Status: <?php echo e($hotel->status); ?></h6>
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-4">
                                            <?php if(isset($hotel->logo)): ?>
                                                <img src="<?php echo e(asset($hotel->logo)); ?>" alt="<?php echo e($hotel->name); ?>"
                                                     style="width: 300px; height: 300px">
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-12 col-lg-12 col-xl-12 mt-2 mb-2">
                                                    <h4 class="mb-4 m-2"><strong>Rooms</strong></h4>
                                            <div class="row mb-2">
                                                <div class="col-md-12 text-right">
                                                    <a href="<?php echo e(route('manager.hotel.room.add', $hotel->id)); ?>" class="btn btn-sm btn-info">Add Room</a>
                                                </div>
                                            </div>
                                            <table class="table table-bordered table-striped mb-none" id="data-table">
                                                <thead>
                                                <tr>
                                                    <th width="50">#</th>
                                                    <th>Room</th>
                                                    <th>Type</th>
                                                    <th>Amount</th>
                                                    <th width="220">Created At</th>
                                                    <th width="50">Status</th>
                                                    <th width="100">Option</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $hotel->rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr class="<?php if(($key%2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                                                        <td><?php echo e(($key+1)); ?></td>
                                                        <td>
                                                            <strong class="text-capitalize"><?php echo e($val->room_number); ?></strong>
                                                            <span class="text-capitalize"><?php echo e($val->type); ?></span><br>
                                                            <span>Attached Bath: <?php echo e(($val->attached_bath == 1) ? "Yes" : "No"); ?></span><br>
                                                        </td>
                                                        <td>
                                                            <span><?php echo e($val->roomType->name.'( '.$val->roomType->capacity." P)"); ?></span>
                                                        </td>
                                                        <td><?php echo e($val->amount); ?></td>
                                                        <td><?php echo e(date('F d, Y h:i A', strtotime($val->created_at))); ?></td>
                                                        <td>
                                                            <?php if(strtolower($val->status) === 'active'): ?>
                                                                <span class="text-capitalize badge-success p-1"><?php echo e($val->status); ?></span>
                                                            <?php else: ?>
                                                                <span class="text-capitalize badge-danger p-1"><?php echo e($val->status); ?></span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="center hidden-phone" width="100">
                                                            <a href="<?php echo e(route('manager.hotel.room.edit', [$hotel->id, $val->id])); ?>"
                                                               class="btn btn-sm btn-success"> <i
                                                                        class="fa fa-edit"></i> </a>
                                                            <span style="cursor: pointer"
                                                                  class="btn btn-sm btn-danger btn-delete delete_<?php echo e($val->id); ?>"
                                                                  data-id="<?php echo e($val->id); ?>"><i class="fa fa-trash-o"></i></span>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="hotelDeleteModal" tabindex="-1" role="dialog" aria-labelledby="hotelDeleteModal"
         aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>Delete Room</h4>
                </div>
                <div class="modal-body">
                    <strong>Are you sure to delete this Room?</strong>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">No</button>
                    <button type="button" class="btn btn-success btn-sm yes-btn">Yes</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables/media/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables-bs3/assets/js/datatables.js')); ?>"></script>
    <script>
      $(document).ready(function () {
        $('#data-table').DataTable();


        $(document).on('click', '.yes-btn', function () {
          var pid = $(this).data('id');
          var hotel_id = "<?php echo e($hotel->id); ?>";
          var $this = $('.delete_' + pid)
          $.ajax({
            url: "<?php echo e(route('manager.hotel.room.delete')); ?>",
            method: "delete",
            dataType: "html",
            data: {id: pid, hotel_id: hotel_id},
            success: function (data) {
              if (data === "success") {
                $('#hotelDeleteModal').modal('hide')
                $this.closest('tr').css('background-color', 'red').fadeOut();
              }
            }
          });
        })

        $(document).on('click', '.btn-delete', function () {
          var pid = $(this).data('id');
          $('.yes-btn').data('id', pid);
          $('#hotelDeleteModal').modal('show')
        });
      })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.manager_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel_booking\resources\views/manager/hotel/details.blade.php ENDPATH**/ ?>