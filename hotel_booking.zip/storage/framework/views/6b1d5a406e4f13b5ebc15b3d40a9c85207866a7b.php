<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>Customer | Dashboard</title>
    <meta content="Admin Dashboard" name="description"/>
    <meta content="Themesbrand" name="author"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/frontend/img/favicon.png')); ?>">


    <link href="<?php echo e(asset('assets/admin/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/admin/css/icons.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/admin/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <?php echo $__env->yieldContent('stylesheet'); ?>

</head>
<body class="fixed-left">
<!-- Loader -->
<div id="preloader">
    <div id="status">
        <div class="spinner"></div>
    </div>
</div>

<div id="wrapper">
    <!-- ========== Left Sidebar Start ========== -->
    <div class="left side-menu">

        <!-- LOGO -->
        <div class="topbar-left">
            <div class="">
                <a href="<?php echo e(route('home')); ?>" class="logo"><img src="<?php echo e(asset('assets/admin/images/logo-sm.png')); ?>" height="36" alt="logo"></a>
            </div>
        </div>
        <div class="sidebar-inner slimscrollleft">
            <div id="sidebar-menu">
                <ul>
                    
                    <li>
                        <a href="" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span>  Dashboard</span> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('customer.booking.list')); ?>" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span>  Booked</span> </a>
                    </li>

                </ul>
            </div>
            <div class="clearfix"></div>
        </div> <!-- end sidebarinner -->
    </div>
    <!-- Left Sidebar End -->

    <!-- Start right Content here -->
    <div class="content-page">

        <!-- Start content -->
        <div class="content">

            <!-- Top Bar Start -->
            <div class="topbar">

                <nav class="navbar-custom">
                    <!-- Search input -->
                    <div class="search-wrap" id="search-wrap">
                        <div class="search-bar">
                            <input class="search-input" type="search" placeholder="Search"/>
                            <a href="#" class="close-search toggle-search" data-target="#search-wrap">
                                <i class="mdi mdi-close-circle"></i>
                            </a>
                        </div>
                    </div>

                    <ul class="list-inline float-right mb-0">
                        <!-- Fullscreen -->
                        <li class="list-inline-item dropdown notification-list hidden-xs-down">
                            <a class="nav-link waves-effect" href="#" id="btn-fullscreen">
                                <i class="mdi mdi-fullscreen noti-icon"></i>
                            </a>
                        </li>

                        <!-- User-->
                        <li class="list-inline-item dropdown notification-list">
                            <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#"
                               role="button"
                               aria-haspopup="false" aria-expanded="false">
                                <img src="<?php echo e(asset('assets/admin/images/users/avatar-1.jpg')); ?>" alt="user" class="rounded-circle">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                <a class="dropdown-item" href="<?php echo e(route('customer.change-profile')); ?>"><i class="dripicons-user text-muted"></i> Profile</a>
                                <a class="dropdown-item" href="<?php echo e(route('customer.change-password')); ?>"><i class="dripicons-gear text-muted"></i> Settings</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo e(route('customer.logout')); ?>"><i class="dripicons-exit text-muted"></i> Logout</a>
                            </div>
                        </li>
                    </ul>
                    <!-- Page title -->
                    <ul class="list-inline menu-left mb-0">
                        <li class="list-inline-item">
                            <button type="button" class="button-menu-mobile open-left waves-effect">
                                <i class="ion-navicon"></i>
                            </button>
                        </li>
                        <li class="hide-phone list-inline-item app-search">
                            <h3 class="page-title"><?php echo $__env->yieldContent('title'); ?></h3>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </nav>
            </div>
            <!-- Top Bar End -->

            <div class="page-content-wrapper">
                <div class="container-fluid">

                    <?php echo $__env->yieldContent('content'); ?>

                </div><!-- container -->
            </div> <!-- Page content Wrapper -->
        </div>
        <footer class="footer">
            © 2020 Ecommerce
        </footer>
    </div>
</div>

<script src="<?php echo e(asset('assets/admin/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/waves.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/jquery.scrollTo.min.js')); ?>"></script>


<!-- App js -->
<script src="<?php echo e(asset('assets/admin/js/app.js')); ?>"></script>

<script>
  $(document).ready(function () {
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
  })
</script>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('script'); ?>


</body>
</html><?php /**PATH C:\xampp\htdocs\hotel_booking\resources\views/layouts/customer_layout.blade.php ENDPATH**/ ?>