


<?php $__env->startSection('stylesheet'); ?>
    <link href="<?php echo e(asset('assets/admin/css/select2.min.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- slider Area Start-->
    <div class="slider-area ">
        <!-- Mobile Menu -->
        <div class="slider-active dot-style">
            <div class="single-slider  hero-overly slider-height d-flex align-items-center"
                 data-background="assets/frontend/assets/img/hero/h1_hero.jpg">
                <div class="container">
                    <div class="row justify-content-center text-center">
                        <div class="col-xl-9">
                            <div class="h1-slider-caption">
                                <h1 data-animation="fadeInUp" data-delay=".4s">top hotel in the city</h1>
                                <h3 data-animation="fadeInDown" data-delay=".4s">Hotel & Resourt</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider  hero-overly slider-height d-flex align-items-center"
                 data-background="assets/frontend/assets/img/hero/h1_hero.jpg">
                <div class="container">
                    <div class="row justify-content-center text-center">
                        <div class="col-xl-9">
                            <div class="h1-slider-caption">
                                <h1 data-animation="fadeInUp" data-delay=".4s">top hotel in the city</h1>
                                <h3 data-animation="fadeInDown" data-delay=".4s">Hotel & Resourt</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="single-slider  hero-overly slider-height d-flex align-items-center"
                 data-background="assets/frontend/assets/img/hero/h1_hero.jpg">
                <div class="container">
                    <div class="row justify-content-center text-center">
                        <div class="col-xl-9">
                            <div class="h1-slider-caption">
                                <h1 data-animation="fadeInUp" data-delay=".4s">top hotel in the city</h1>
                                <h3 data-animation="fadeInDown" data-delay=".4s">Hotel & Resourt</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- slider Area End-->

    <!-- Booking Room Start-->
    <div class="booking-area">
        <div class="container">
            <div class="row ">
                <div class="col-12">
                    <form action="<?php echo e(route('hotel.search')); ?>" method="get">
                        <div class="booking-wrap d-flex justify-content-between align-items-center">
                            <!-- select in date -->
                            <div class="single-select-box mb-30">
                                <!-- select out date -->
                                <div class="boking-tittle">
                                    <span> Check In Date:</span>
                                </div>
                                <div class="boking-datepicker">
                                    <input id="datepicker1"
                                           value="<?php if(isset($request->check_in)): ?> <?php echo e($request->check_in); ?> <?php endif; ?>"
                                           name="check_in" placeholder="10/12/2020"/>
                                </div>
                            </div>

                            <!-- Single Select Box -->
                            <div class="single-select-box mb-30">
                                <!-- select out date -->
                                <div class="boking-tittle">
                                    <span>Check OutDate:</span>
                                </div>
                                <div class="boking-datepicker">
                                    <input id="datepicker2"
                                           value="<?php if(isset($request->check_out)): ?> <?php echo e($request->check_out); ?> <?php endif; ?>"
                                           name="check_out" placeholder="12/12/2020"/>
                                </div>
                            </div>

                            <!-- Single Select Box -->
                            <div class="single-select-box mb-30">
                                <div class="boking-tittle">
                                    <span>District:</span>
                                </div>
                                <div class="select-this">
                                    <div class="select-itms">
                                        <select name="district" id="select2">
                                            <option value="">Choose</option>
                                            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <optgroup label="<?php echo e($division->name); ?>">
                                                    <?php $__currentLoopData = $division->district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($val->id); ?>"
                                                                <?php if($request->district == $val->id): ?> selected <?php endif; ?>><?php echo e($val->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </optgroup>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Select Box -->
                            <div class="single-select-box mb-30">
                                <div class="boking-tittle">
                                    <span>Rooms:</span>
                                </div>
                                <div class="select-this">
                                    <div class="select-itms">
                                        <select name="select" id="select3">
                                            <option value="">Choose</option>
                                            <?php $__currentLoopData = $rt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($r->id); ?>"
                                                        <?php if($request->room == $r->id): ?> selected <?php endif; ?>><?php echo e($r->name); ?>

                                                    (<?php echo e($r->capacity); ?>)
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Single Select Box -->
                            <div class="single-select-box pt-45 mb-30">
                                <button type="submit" class="btn select-btn">Search Now</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Booking Room End-->

    <?php if(count($rooms) > 0): ?>
        <!-- Hotel Start -->
        <section class="room-area">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-8">
                        <!--font-back-tittle  -->
                        <div class="font-back-tittle mb-45">
                            <div class="archivment-front" style="z-index: 0">
                                <h3>Our Hotels</h3>
                            </div>
                            <h3 class="archivment-back">Our Hotels</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-12 m-2">
                            <div class="row">
                                <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4">
                                    <a href="#"><img src="<?php echo e(asset($val->hotel_logo)); ?>" alt="<?php echo e($val->hotel_name); ?>"
                                                     style="height: 100%; width: 100%"></a>
                                </div>
                                <div class="col-sm-8 col-md-8 col-lg-8 col-xl-8 pl-2">
                                    <h2><a href="#"><strong><?php echo e($val->hotel_name); ?></strong></a></h2>
                                    <h4 class="text-capitalize"><i
                                                class="fa fa-map-marker-alt pr-1"></i><?php echo e($val->district_name); ?>

                                        , <?php echo e($val->division_name); ?></h4>
                                    <h4><i class="fa fa-phone pr-1"></i><?php echo e($val->hotel_phone); ?></h4>
                                    <h4><i class="fa fa-at pr-1"></i><?php echo e($val->hotel_email); ?></h4>
                                    <h6><i class="fa fa-home pr-1"></i><strong
                                                style="color: #0000cc"><?php echo e($val->room_number); ?></strong></h6>
                                    <h6><i class="fa fa-users pr-1"></i><?php echo e($val->room_type_name); ?>

                                        (<?php echo e($val->room_type_capacity); ?>)</h6>
                                    <h6><i class="fa fa-dollar-sign pr-1" style="color: #1a202c"></i><strong
                                                style="color: #0000cc"><?php echo e($val->room_amount); ?> Taka/Day</strong></h6>
                                    <h4><a href="#" class="order_btn btn btn-success btn-sm p-3" data-diff="<?php echo e($diff); ?>" data-url="<?php echo e(route('book_room', $val->room_id)); ?>" data-amount="<?php echo e($val->room_amount); ?>">Book Now</a></h4>
                                    
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                    
                        
                    
                
            </div>
        </section>
        <div class="modal fade" id="hotelDeleteModal" tabindex="-1" role="dialog" aria-labelledby="hotelDeleteModal"
             aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Payment</h4>
                    </div>
                    <form method="post" id="payment_form">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <h4>Pay <strong id="pay_amount"></strong> TK</h4>
                            <div class="row">
                                <div class="col-6">
                                    <label for="cod"><input type="radio" name="payment_method" id="cod" checked
                                                            value="cod"> Cash On Delivery</label>
                                </div>
                                <div class="col-6">
                                    <label for="op"><input type="radio" name="payment_method" id="op" value="op"> Online
                                        Payment</label>
                                </div>
                                <div class="col-12 " id="online_payment">
                                    
                                        
                                            
                                                
                                                
                                                       
                                            
                                        
                                        
                                            
                                            
                                                   
                                        
                                        
                                            
                                            
                                        
                                        
                                            
                                            
                                        
                                    
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success btn-sm yes-btn">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>

      $(document).ready(function () {


        $(document).on('change', 'input[name="payment_method"]', function () {
          const id = $(this).attr('id')
          if(id === 'op'){
            $('#online_payment').append('<div class="form-row">\n' +
              '                                        <div class="col-6">\n' +
              '                                            <div class="form-group">\n' +
              '                                                <label for="">Card No</label>\n' +
              '                                                <input type="number" class="form-contact" required name="card_no"\n' +
              '                                                       placeholder="Card No">\n' +
              '                                            </div>\n' +
              '                                        </div>\n' +
              '                                        <div class="col-6">\n' +
              '                                            <label for="">CVC</label>\n' +
              '                                            <input type="number" class="form-contact" required name="cvc_no"\n' +
              '                                                   placeholder="CVC No">\n' +
              '                                        </div>\n' +
              '                                        <div class="col-6">\n' +
              '                                            <label for="">Month</label>\n' +
              '                                            <input type="number" class="form-contact" required name="month" placeholder="Month">\n' +
              '                                        </div>\n' +
              '                                        <div class="col-6">\n' +
              '                                            <label for="">Year</label>\n' +
              '                                            <input type="number" class="form-contact" required name="year" placeholder="Year">\n' +
              '                                        </div>\n' +
              '                                    </div>');
          }else{
            $('#online_payment').empty();
          }
        })

        $(document).on('click', '.order_btn', function () {
          const url = $(this).data('url');
          const diff = $(this).data('diff');
          const amount = $(this).data('amount');
          const taka = amount * diff;
          $('#pay_amount').text(taka);
          $('#payment_form').attr('action', url);
          $('#hotelDeleteModal').modal('show')
        })
      });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel_booking\resources\views/site/hotel_search.blade.php ENDPATH**/ ?>