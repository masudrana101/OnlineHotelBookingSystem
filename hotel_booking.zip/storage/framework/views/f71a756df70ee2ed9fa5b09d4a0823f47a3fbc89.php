

<?php $__env->startSection('stylesheet'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/vendor/jquery-datatables-bs3/assets/css/datatables.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <section class="panel">
                        <header class="panel-heading">
                            <h2 class="panel-title">View Room Booking</h2>
                        </header>
                        <div class="panel-body">
                            <?php if(session()->has('status')): ?>
                                <?php echo session()->get('status'); ?>

                            <?php endif; ?>
                            
                                
                                    
                                
                            
                            <table class="table table-bordered table-striped mb-none" id="data-table">
                                <thead>
                                <tr>
                                    <th width="50">#</th>
                                    <th>Hotel</th>
                                    <th>Room</th>
                                    <th>Address</th>
                                    <th>Payment</th>
                                    <th width="220">Interval</th>
                                    <th width="70">Status</th>
                                    
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php if(($loop->iteration %2) == 0): ?>gradeX <?php else: ?> gradeC <?php endif; ?>">
                                        <td><?php echo e(($loop->iteration  +1)); ?></td>
                                        <td class="text-capitalize" >
                                            <strong><?php echo e($val->room->hotel->name); ?></strong><br>
                                            <span><?php echo e($val->room->hotel->email); ?> </span><br>
                                            <span><?php echo e($val->room->hotel->phone); ?> </span>
                                        </td>
                                        <td class="text-capitalize" >
                                            <strong><?php echo e($val->room->room_number); ?></strong><br>
                                            <span><?php echo e($val->room->roomType->name); ?> <span>(<?php echo e($val->room->roomType->capacity); ?> P)</span></span>
                                            <strong class="text-indigo"><?php echo e($val->room->amount); ?> TK / Night</strong><br>
                                            <span>
                                                <span class="text-capitalize"><?php echo e($val->room->type); ?></span>
                                                <span><?php echo e(($val->room->attached_bath == 0) ? "" : 'With bath'); ?></span>
                                            </span>
                                        </td>
                                        <td>
                                            <span><?php echo e($val->room->hotel->address); ?></span><br>

                                        </td>e
                                        <td>
                                            <strong>Pay: <?php echo e($val->amount); ?> TK</strong><br>
                                            <span class="text-capitalize">By: <?php echo e($val->payment_by); ?></span><br>
                                        </td>
                                        <td>
                                            <span><?php echo e($val->check_in); ?> to <?php echo e($val->check_out); ?></span><br>
                                            <span>Apply at: </span><br>
                                            <span><?php echo e(date('F d, Y h:i A', strtotime($val->created_at))); ?></span>
                                        </td>
                                        <td class="text-capitalize">
                                            <span class="p-2
                                                <?php if($val->status == 'pending'): ?>
                                                    bg-orange
                                                <?php elseif($val->status == 'booked'): ?>
                                                    bg-lime
                                                <?php elseif($val->status == 'canceled'): ?>
                                                    bg-red-600
                                                <?php else: ?>
                                                    bg-success
                                                <?php endif; ?>"
                                            ><?php echo e($val->status); ?></span>
                                        </td>
                                        
                                            
                                            
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables/media/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/vendor/jquery-datatables-bs3/assets/js/datatables.js')); ?>"></script>
    <script>
      $(document).ready(function () {
        $('#data-table').DataTable();
        $(document.body).on('change', 'select[name="status"]', function () {
          const select = $(this).val();
          if(select !== '') {
            $(this).closest('form').submit()
          }
        })
      })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel_booking\resources\views/customer/booked.blade.php ENDPATH**/ ?>